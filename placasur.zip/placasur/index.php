<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Placasur">
    <meta name="author" content="Placasur SA">
    <!-- .ico -->
    <link href='imagenes/placasur.ico' rel='shortcut icon' type='image/x-icon' />

    <title>Placa Sur</title>
    <!-- CSS - bs - custom -->
    <link href="css/estilos.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <!-- fontawesome iconos -->
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link href="fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome/css/brands.css" rel="stylesheet">
    <link href="fontawesome/css/solid.css" rel="stylesheet">
</head>

<body>
    <!-- NAV / menú -->      
    <header class="sticky-md-top border-top border-5 border-primary">
        <nav class="container-fluid navbar navbar-expand-lg bg-light py-0 menutop shadow">
            <div class="container-md">
                <a class="navbar-brand col-6 col-md-3 col-lg-3" href="/" title="Inicio Placa Sur">
                    <!-- logo -->
                    <img src="imagenes/placasur.png" alt=" Placa Sur" class="img-fluid float-left">
                    <h1 class="visually-hidden"> Placa Sur</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item active">
                        <a href="" title="Página principal" class="nav-link">Empresa <span class="visually-hidden">(Home)</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="faq.html" title="Nuestras actividades" class="nav-link">Servicios</a>
                        </li>  
                        <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Productos
                        </a>
                            <div class="dropdown-menu bg-light mt-1 shadow-sm" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">Productos varios</a>
                                <a class="dropdown-item" href="#">Another action</a>
                            </div>
                        </li>  
                        <li class="nav-item">
                            <a href="faq.html" title="Nuestras actividades" class="nav-link">Presupuestos</a>
                        </li>                  
                        <li class="nav-item">
                            <a href="faq.html" title="Nuestras actividades" class="nav-link">Novedades</a>
                        </li>  
                        <!-- contacto -->
                        <li class="nav-item">
                            <a href="#contactanos" title="Contactanos" class="nav-link">Contacto</a>
                        </li>                     
                    </ul>
                </div>
            </div>
        </nav>
    </header>  

    <!-- carousel - slide imagenes -->
    <!-- si no corre poner "false" ==> data-bs-ride="false" -->
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
            <img src="imagenes/foto-carousel-1.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block pt-2 pe-3 ps-3 pb-0 bg-primary text-start col-md-7 bg-opacity-75 shadow">
                <p class="lead mb-0">Lo que necesites para tus proyectos</p>
                <p class="h2 mt-0"><strong>Lo encontrás acá</strong></p>
            </div>
            </div>
            <div class="carousel-item">
            <img src="imagenes/foto-carousel-2.jpg" class="d-block w-100" alt="...">
            <div class="carousel-caption d-none d-md-block pt-2 pe-3 ps-3 pb-0 bg-primary text-start col-md-7 bg-opacity-75">
                <p class="lead mb-0">Lo que necesites para tus proyectos</p>
                <p class="h2 mt-0"><strong>Lo encontrás acá</strong></p>
            </div>
            </div>
        </div>
        <button class="carousel-control-prev ps-3" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
            <img src="imagenes/anterior.png" class="ms-2 d-none d-lg-block d-sm-none">
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next pe-3" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
            <img src="imagenes/siguiente.png" class="me-2 d-none d-lg-block d-sm-none">
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Principales servicios -->
    <div class="container-md mt-5">
        <div class="row">     
            <!--productos-->
            <div class="col-sm-12 col-md-4 mb-5">  
                <a href="productos.php" title="Catálogo de productos" class="box">
                    <img src="imagenes/productos.png" alt="Productos Placa Sur" class="img-fluid shadow">
                </a>
            </div>
            <!--servicios-->
            <div class="col-sm-12 col-md-4 mb-5">  
                <a href="servicios.php" title="Servicios PlacaSur" class="box">
                    <img src="imagenes/servicios.png" alt="Productos Placa Sur" class="img-fluid shadow">
                </a>
            </div>
            <!--novedades-->
            <div class="col-sm-12 col-md-4 mb-5">  
                <a href="novedades.php" title="Todas las novedades de PlacaSur" class="box">
                    <img src="imagenes/novedades.png" alt="Productos Placa Sur" class="img-fluid shadow">
                </a>
                <!-- <a href="novedades.php" class="box link-light" target="_blank">
                    <div class="card card-cover">
                        <img src="imagenes/novedades.png" class="card-img h-100" alt="...">
                        <div class="card-img-overlay d-flex justify-content-end align-items-end">
                            <span class="fs-4 fw-light pb-0">NOVEDADES</span>
                        </div>
                    </div>
                </a>   -->
            </div>
        </div>        
    </div>

    <!-- slide logos -->
    <!-- !!!! si es menor a 9 imagenes hay que repetir !!!! -->
    <div class="container">
    <div class="slider">
        <div class="slide-track">
            <div class="slide">
                <img src="imagenes/logos/masisa.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/faplac.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/flipasto.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/durlok.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/sadepan.png" class="mx-md-4 mx-0" alt="" />
            </div>
        
            <div class="slide">
                <img src="imagenes/logos/masisa.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/faplac.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/flipasto.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/durlok.png" class="mx-md-4 mx-0" alt="" />
            </div>
            <div class="slide">
                <img src="imagenes/logos/sadepan.png" class="mx-md-4 mx-0" alt="" />
            </div>
        </div>
    </div>
    </div>
    <!--FIN slide logos -->

    <!-- footer -->
    <div class="bg-dark bg-gradient">
        <div class="container py-4 small">
            <div class="row d-md-flex flex-md-row d-sm-flex flex-sm-column-reverse">
                <div class="col mt-md-0 mt-4">
                    <img src="imagenes/datafiscal-qr.png">
                </div>
                <div class="col-md-3 align-content-end">
                    <p class="h4 text-white">Contactanos</p>
                    <ul class="list-unstyled text-white-50">
                        <li class="pb-2"><i class="far fa-building"></i> Av. H. Yrigoyen 15750 <br>
                        (1852) Burzaco, Buenos Aires, Argentina</li>
                        <li class="pb-2"><i class="fas fa-phone-alt"></i> (5411) 4002-4400 / 4238-4000</li>
                        <li class="text-white-50"><i class="far fa-envelope"></i> <a href="mailto:info@placasur.com.ar" class="text-decoration-none text-white-50"> info@placasur.com.ar </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN footer -->


    <script src="js/jquery.min.js"></script>
    <!-- <script src="libs/bootstrap/dist/js/bootstrap.min.js"></script> -->
    <script src="libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript" charset="utf-8">

        // tooltip
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
            
        // menú dropdown hover
        const $dropdown = $(".dropdown");
        const $dropdownToggle = $(".dropdown-toggle");
        const $dropdownMenu = $(".dropdown-menu");
        const showClass = "show";

        $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 768px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
        });
    </script>

</body>
</html>
