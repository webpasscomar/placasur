<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Placasur">
    <meta name="author" content="Placasur SA">
    <!-- .ico -->
    <link href='imagenes/placasur.ico' rel='shortcut icon' type='image/x-icon' />

    <title>Placa Sur</title>
    <!-- CSS - bs - custom -->
    <link href="css/estilos.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <!-- fontawesome iconos -->
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link href="fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome/css/brands.css" rel="stylesheet">
    <link href="fontawesome/css/solid.css" rel="stylesheet">
</head>

<body>
    <!-- NAV / menú -->      
    <header class="sticky-md-top border-top border-5 border-primary">
        <nav class="container-fluid navbar navbar-expand-lg bg-light py-0 menutop shadow">
            <div class="container-md">
                <a class="navbar-brand col-6 col-md-3 col-lg-3" href="/" title="Inicio Placa Sur">
                    <!-- logo -->
                    <img src="imagenes/placasur.png" alt=" Placa Sur" class="img-fluid float-left">
                    <h1 class="visually-hidden"> Placa Sur</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                        <a href="" title="Página principal" class="nav-link">Empresa <span class="visually-hidden">(Home)</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="" title="Nuestras actividades" class="nav-link">Servicios</a>
                        </li>  
                        <li class="nav-item dropdown active">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Productos
                        </a>
                            <div class="dropdown-menu bg-light mt-1 shadow-sm" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item active" href="#">Placas</a>
                                <a class="dropdown-item" href="#">Adhesivos y Barnices</a>
                                <a class="dropdown-item" href="#">Molduras</a>
                                <a class="dropdown-item" href="#">Enchapados</a>
                                <a class="dropdown-item" href="#">Construcción</a>
                                <a class="dropdown-item" href="#">Tapacantos</a>
                                <a class="dropdown-item" href="#">Herrajes</a>
                            </div>
                        </li>  
                        <li class="nav-item">
                            <a href="" title="Nuestras actividades" class="nav-link">Presupuestos</a>
                        </li>                  
                        <li class="nav-item">
                            <a href="" title="Nuestras actividades" class="nav-link">Novedades</a>
                        </li>  
                        <!-- contacto -->
                        <li class="nav-item">
                            <a href="" title="Contactanos" class="nav-link">Contacto</a>
                        </li>     
                        <!-- buscador -->
                        <li class="nav-item search">
                        <form>
                            <div class="animated-search m-md-0 mb-sm-4">
                            <input type="search" id="animated-input">
                            <a href="#">
                                <i class="fas fa-search" id="searchBtn"></i>
                            </a>
                            </div>
                        </form>
                        </li>           
                    </ul>                    
                </div>
            </div>
        </nav>
    </header>           


    <!-- jumbotrob / título productos -->
    <div class="container-fluid p-0 mb-3">
        <div class="jumbotron jumbotron-fluid imagencover px-4 mb-0 d-flex align-items-center text-center"> 
            <div class="container">
                <p class="text-black-50 display-5">Placas</p>
            </div>
        </div>
        <div class="bg-opacity-10 bg-black d-none d-lg-block d-sm-none">
            <div class="container mt-md-n5 pt-1">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent px-0 py-2">
                  <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Inicio</a></li>
                  <li class="breadcrumb-item"><a href="productos.php" class="text-decoration-none">Productos</a></li>
                  <li class="breadcrumb-item active text-black" aria-current="page">Placas</li>
                </ol>
              </nav>
            </div>
        </div>
    </div>
    <!-- card productos -->
    <div class="container-md mt-5">
        <div class="row">     
        <!-- Faplac -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/placas.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Faplac</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="productos/placas/faplac/nature.php" class="text-decoration-none" title="Placas Faplac - Línea Nature"><small class="light">Línea</small> <span class="medium">Nature</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Nórdica"><small class="light">Línea</small>  <span class="medium">Nórdica</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Étnica"><small class="light">Línea</small>  <span class="medium">Étnica</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Urban Concept"><small class="light">Línea</small>  <span class="medium">Urban Concept</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Hilados"><small class="light">Línea</small>  <span class="medium">Hilados</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Clásica"><small class="light">Línea</small>  <span class="medium">Clásica</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Faplac - Línea Lisos"><small class="light">Línea</small>  <span class="medium">Lisos</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Egger -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/adhesivos.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Egger</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Egger - Línea Feelwood"><small class="light">Línea</small>  <span class="medium">Feelwood</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Egger - Línea Touch"><small class="light">Línea</small>  <span class="medium">Touch</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Egger - Línea Esencia"><small class="light">Línea</small>  <span class="medium">Esencia</span></a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Egger - Línea Materia"><small class="light">Línea</small>  <span class="medium">Materia</span></a></li>                            
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Egger - Línea Clásica"><small class="light">Línea</small>  <span class="medium">Clásica</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Rehau -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/molduras.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Rehau</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">           
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Rehau"><span class="medium">Rehau</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Sadepam -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/enchapados.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Sadepam</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">          
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Sadepam - Línea Simplece"><span class="medium">Simplece</span></a></li>                                    
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Sadepam - Línea Ragazzi"><span class="medium">Ragazzi</span></a></li>                                  
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Sadepam - Línea Piacere"><span class="medium">Piacere</span></a></li>                               
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Sadepam - Línea Sensazioni"><span class="medium">Sensazioni</span></a></li>                          
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Sadepam - Línea Potenza"><span class="medium">Potenza</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Rauvisio -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/construccion.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Rauvisio</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas de Rauvisio - Aislante">Aislante</a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas de Rauvisio - Construcción en sseco">Construcción en seco</a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas de Rauvisio - Pisos Flotantes">Pisos Flotantes</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Guillermina -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/tapacantos.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Guillermina</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Guillermina - Rehau">Rehau</a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Guillermina - Egger">Egger</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Obs -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100">
                <img src="imagenes/productos/herrajes.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                    <div class="card-header border-0 border-top border-5 border-primary">
                        <p class="card-title h5 mb-0 fw-semibold">Obs</p>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush rounded-0 border-0">
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Obs - Eurohard">Eurohard</a></li>
                            <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> <a href="" class="text-decoration-none" title="Placas Obs - Otros">Otros</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- fin card productos -->

    <!-- footer -->
    <div class="bg-dark bg-gradient">
        <div class="container py-4 small">
            <div class="row d-md-flex flex-md-row d-flex flex-column-reverse">
                <div class="col mt-md-0 mt-4">
                    <img src="imagenes/datafiscal-qr.png">
                </div>
                <div class="col-md-3 align-content-end">
                    <p class="h4 text-white">Contactanos</p>
                    <ul class="list-unstyled text-white-50">
                        <li class="pb-2"><i class="far fa-building"></i> Av. H. Yrigoyen 15750 <br>
                        (1852) Burzaco, Buenos Aires, Argentina</li>
                        <li class="pb-2"><i class="fas fa-phone-alt"></i> (5411) 4002-4400 / 4238-4000</li>
                        <li class="text-white-50"><i class="far fa-envelope"></i> <a href="mailto:info@placasur.com.ar" class="text-decoration-none text-white-50"> info@placasur.com.ar </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN footer -->


    <script src="js/jquery.min.js"></script>
    <!-- <script src="libs/bootstrap/dist/js/bootstrap.min.js"></script> -->
    <script src="libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript" charset="utf-8">

        // tooltip
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
            
        // menú dropdown hover
        const $dropdown = $(".dropdown");
        const $dropdownToggle = $(".dropdown-toggle");
        const $dropdownMenu = $(".dropdown-menu");
        const showClass = "show";

        $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 768px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
        });

        // search animado
        const searchBtn = document.querySelector('#searchBtn'); 
        const animatedInput = document.querySelector('#animated-input');

        searchBtn.addEventListener('click', openSearch);

        function openSearch(e) {
        animatedInput.focus();
        }
        // Check if there is text in input every 50ms
        setInterval(function() {
        if (animatedInput.value) {
            animatedInput.style.width = '225px';
        }
        }, 50);
    </script>

</body>
</html>
