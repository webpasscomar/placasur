<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Placasur">
    <meta name="author" content="Placasur SA">
    <!-- .ico -->
    <link href='imagenes/placasur.ico' rel='shortcut icon' type='image/x-icon' />

    <title>Placa Sur</title>
    <!-- CSS - bs - custom -->
    <link href="css/estilos.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
    <!-- fontawesome iconos -->
    <link href="fontawesome/css/all.css" rel="stylesheet">
    <link href="fontawesome/css/fontawesome.css" rel="stylesheet">
    <link href="fontawesome/css/brands.css" rel="stylesheet">
    <link href="fontawesome/css/solid.css" rel="stylesheet">
</head>

<body>
    <!-- NAV / menú -->      
    <header class="sticky-md-top border-top border-5 border-primary">
        <nav class="container-fluid navbar navbar-expand-lg bg-white py-0 menutop shadow">
            <div class="container-md">
                <a class="navbar-brand col-6 col-md-3 col-lg-3" href="/" title="Inicio Placa Sur">
                    <!-- logo -->
                    <img src="imagenes/placasur.png" alt=" Placa Sur" class="img-fluid float-left">
                    <h1 class="visually-hidden"> Placa Sur</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                        <a href="" title="Página principal" class="nav-link">Empresa <span class="visually-hidden">(Home)</span></a>
                        </li>
                        <li class="nav-item">
                            <a href="servicios.php" title="Nuestros servicios" class="nav-link">Servicios</a>
                        </li>  
                        <li class="nav-item dropdown active">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Productos
                        </a>
                            <div class="dropdown-menu bg-light mt-1 shadow-sm" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="placas.php">Placas</a>
                                <a class="dropdown-item" href="#">Adhesivos y Barnices</a>
                                <a class="dropdown-item" href="#">Molduras</a>
                                <a class="dropdown-item" href="#">Enchapados</a>
                                <a class="dropdown-item" href="#">Construcción</a>
                                <a class="dropdown-item" href="#">Tapacantos</a>
                                <a class="dropdown-item" href="#">Herrajes</a>
                            </div>
                        </li>  
                        <li class="nav-item">
                            <a href="" title="Nuestras actividades" class="nav-link">Presupuestos</a>
                        </li>                  
                        <li class="nav-item">
                            <a href="" title="Nuestras actividades" class="nav-link">Novedades</a>
                        </li>  
                        <!-- contacto -->
                        <li class="nav-item">
                            <a href="" title="Contactanos" class="nav-link">Contacto</a>
                        </li>     
                        <!-- buscador -->
                        <li class="nav-item search">
                        <form>
                            <div class="animated-search m-md-0 mb-sm-4">
                            <input type="search" id="animated-input">
                            <a href="#">
                                <i class="fas fa-search" id="searchBtn"></i>
                            </a>
                            </div>
                        </form>
                        </li>           
                    </ul>                    
                </div>
            </div>
        </nav>
    </header>           


    <!-- jumbotrob / título productos -->
    <div class="container-fluid p-0 mb-3">
        <div class="jumbotron jumbotron-fluid imagencover px-4 mb-0 d-flex align-items-center text-center mt-md-n2"> 
            <div class="container">
                <p class="text-black-50 display-5">Productos</p>
            </div>
        </div>
        <div class="bg-opacity-10 bg-black d-none d-lg-block d-sm-none">
            <div class="container mt-md-n5 pt-1">
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb bg-transparent px-0 py-2">
                  <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Inicio</a></li>
                  <li class="breadcrumb-item active text-black" aria-current="page">Productos</li>
                </ol>
              </nav>
            </div>
        </div>
    </div>
    <!-- card productos -->
    <div class="container-md mt-5">
        <div class="row">     
        <!-- placas -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="placas.php" class="text-decoration-none stretched-link" title="Ver todos los Productos de placas">
                    <img src="imagenes/productos/placas.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold link-secondary">Placas</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Faplac</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Egger</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Rehau</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Sadepam</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Rauvisio</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Guillermina</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 fa-2xs text-primary"></i> Obs</li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Adhesivos y Barnices -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                     <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de Adhesivos y Barnices">
                    <img src="imagenes/productos/adhesivos.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold link-secondary">Adhesivos y Barnices</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i>Barnices</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Adhesivos</li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Molduras -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de molduras">
                    <img src="imagenes/productos/molduras.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold link-secondary">Molduras</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Decoforma </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Construcción en sseco</li>                            
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Pisos Flotantes </li>                            
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Aislante </li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Enchapados -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de Enchapados">
                    <img src="imagenes/productos/enchapados.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold text-secondary">Enchapados</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Cantochap</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Formica</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Chapadur </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Terciado </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Terciado de Pino</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Terciado Guatambu</li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Terciado Fenolico Plastificado</li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Construcción -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de Construcción">
                    <img src="imagenes/productos/construccion.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold link-secondary">Construcción</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Aislante </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Estisol </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Molduras </li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Tapacantos -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de Tapacantos">
                    <img src="imagenes/productos/tapacantos.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold">Tapacantos</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Rehau </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Egger </li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Herrajes para mueble y concina -->
            <div class="col-sm-12 col-md-3 mb-5">  
                <div class="card shadow info-box__shadow h-100 pb-1">
                    <a href="" class="text-decoration-none stretched-link" title="Todos los Productos de Tapacantos">
                    <img src="imagenes/productos/herrajes.jpg" class="card-img-top d-none d-sm-none d-md-block" alt="Detalle del producto">
                        <div class="card-header border-0 border-top border-5 border-primary">
                            <p class="card-title h5 mb-0 fw-semibold link-secondary">Herrajes para mueble y concina</p>
                        </div>
                        <div class="card-body p-0">
                            <ul class="list-group list-group-flush rounded-0 border-0">
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Eurohard </li>
                                <li class="list-group-item border-0" aria-current="true"> <i class="fa-solid fa-diamond pe-1 text-primary fa-2xs"></i> Otros </li>
                            </ul>
                        </div>
                    </a>
                </div>
            </div>
            
        </div>
    </div>
    <!-- fin card productos -->

    <!-- footer -->
    <div class="bg-dark">
        <div class="container py-4 small">
            <div class="row">
                <!-- contacto -->
                <div class="col-md-3">
                    <p class="h6 fw-bold text-white">Contacto</p>
                    <ul class="list-unstyled light text-light">
                        <li> Av. H. Yrigoyen 15750 (1852) <br>
                        Burzaco, Buenos Aires, Argentina</li>
                        <li class="pt-3 pb-2 fw-bold h5 text-white"> (5411) 4002-4400 | <br>
                        4238-4000</li>
                    </ul>
                    <p class="h6 fw-bold text-white">Horarios</p>
                    <span class="text-light light"> lun a vier 9 a 12 y de 14 a 17:30</span>
                </div>
                <!-- categorias -->
                <div class="col-md-3">
                <p class="h6 fw-bold text-white">Categorías de productos</p>
                    <ul class="list-unstyled text-white-50 light">
                        <li><a href="/" class="text-decoration-none link-light" title="Saber más sobre la Empresa"> Empresa </a></li>
                        <li><a href="servicios.php" class="text-decoration-none link-light" title="Todos los servicios"> Servicios </a></li>
                        <li><a href="productos.php" class="text-decoration-none link-light" title="Todos nuestros productos"> Productos </a></li>
                        <li><a href="/" class="text-decoration-none link-light" title="Solicitá tu presupuesto"> Presupuestos </a></li>
                        <li><a href="/" class="text-decoration-none link-light" title="Todas la últimas novedades"> Novedades </a></li>
                        <li><a href="/" class="text-decoration-none link-light" title="Nuestros contactos"> contactos </a></li>
                    </ul>
                </div>
                <!-- data fiscal -->
                <div class="col-md-3">
                <p class="h6 fw-bold text-white">Data fiscal</p>
                    <img src="imagenes/datafiscal-qr.png" title="Imagen de data fiscal de la empresa">
                </div>
                <!-- redes -->
                <div class="col-md-3">
                    <p class="h6 fw-bold text-white">Nuestras redes</p>
                    <ul class="list-group list-group-horizontal">
                        <li class="list-group-item bg-transparent ps-0 border-0 light text-light">
                            <a href="/" class="text-decoration-none link-light" title="Mirá nuestro canal de youtube"> <i class="fa-brands fa-youtube"></i> </a>
                        </li>
                        <li class="list-group-item bg-transparent ps-0 border-0 light text-light"> 
                            <a href="/" class="text-decoration-none link-light" title="Nuestro Instagram"> <i class="fa-brands fa-instagram"></i> </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- FIN footer -->


    <script src="js/jquery.min.js"></script>
    <!-- <script src="libs/bootstrap/dist/js/bootstrap.min.js"></script> -->
    <script src="libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript" charset="utf-8">

        // tooltip
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
            
        // menú dropdown hover
        const $dropdown = $(".dropdown");
        const $dropdownToggle = $(".dropdown-toggle");
        const $dropdownMenu = $(".dropdown-menu");
        const showClass = "show";

        $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 768px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
        });

        // search animado
        const searchBtn = document.querySelector('#searchBtn'); 
        const animatedInput = document.querySelector('#animated-input');

        searchBtn.addEventListener('click', openSearch);

        function openSearch(e) {
        animatedInput.focus();
        }
        // Check if there is text in input every 50ms
        setInterval(function() {
        if (animatedInput.value) {
            animatedInput.style.width = '225px';
        }
        }, 50);
    </script>

</body>
</html>
